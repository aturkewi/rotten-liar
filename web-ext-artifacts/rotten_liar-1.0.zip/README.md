# Rotten Liar

Firefox extension that allows the user to set scores on a Rotten Tomatoes movie or TV show.

![Rotten Liar Example](https://i.imgur.com/SsMEPgr.mp4)

## Why

This extension makes it much easier to update score for movies and TV shows so you can then screenshot them and send them to friends and family. This makes it eaiser to covince everyone to watch your favorite movie even if it has a terrible score on Rotten Tomatoe.

Note: This extension only works if the person does not go to RT to check for themselves. This bug will not be fixed.
